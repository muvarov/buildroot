#!/bin/bash
export DEVICE_CREDENTIAL=/fdoclient/device_credential
fdo-client-linuxapp
